<?php include 'db_connect.php' ?>
<style>
   
</style>

<div class="container-fluid">

	<div class="row">
		<div class="col-lg-12">
			
		</div>
	</div>

	<div class="row mt-3 ml-3 mr-3">
			<div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                    <?php echo "Welcome back ". $_SESSION['login_name']."!"  ?>
                                        
                    </div>
                </div>
            </div>
	</div>
	<!-- <div class="row mt-3 ml-3 mr-3"> -->
		<!-- <div class="col-lg-12"> -->
			<!-- <div class="jumbotron"> -->
  				<!-- <h1 class="display-4">Payroll Management System</h1> -->
  				<!-- <p class="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p> -->
  				<!-- <hr class="my-4"> -->
  				<!-- <p>It uses utility classes for typography and spacing to space content out within the larger container.</p> -->
 				<!-- <p class="lead"> -->
    			<!-- <a class="btn btn-primary btn-lg" href="http://localhost/payroll/index.php?page=payroll" role="button">Learn more</a> -->
  				<!-- </p> -->
			<!-- </div>	 -->
		<!-- </div> -->
	<!-- </div> -->

</div>
<script>
	
</script>