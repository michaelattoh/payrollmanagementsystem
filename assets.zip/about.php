<div class="container-fluid " >
			<div class="col-lg-12">
				
				<br />
				<br />
				<a class="btn btn-dark" href="http://localhost/payroll/index.php?page=home" role="button">Back</a>
				<br />
				<br />
				<div class="card">
					<div class="card-header">
						<span><b>About</b></span>
						
					</div>
                </div>
				<!-- <div>
					<img src="assets/img/error.png" alt="">
					</div> -->
            </div>
</div>
